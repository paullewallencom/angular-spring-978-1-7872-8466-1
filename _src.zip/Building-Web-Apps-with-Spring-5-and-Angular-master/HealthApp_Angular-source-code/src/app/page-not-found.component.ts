import {Component} from '@angular/core';

@Component({
  selector: '',
  templateUrl: './page-not-found.component.html'
})
export class PageNotFoundComponent {
}
