export class Rx {
  public patientId: string;
  public patientName: string;
  public symptoms: string;
  public medicine: string;
  constructor() {}
}

export class RxStatus {
  public code = '';
  public message = '';
  constructor() {}
}
