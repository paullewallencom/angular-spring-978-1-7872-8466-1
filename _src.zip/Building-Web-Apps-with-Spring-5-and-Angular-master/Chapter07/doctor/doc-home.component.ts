
import {Component, OnInit} from '@angular/core';

@Component({
  templateUrl: './doc-home.component.html',
})
export class DocHomeComponent implements OnInit {
  ngOnInit(): void {
  }
}
