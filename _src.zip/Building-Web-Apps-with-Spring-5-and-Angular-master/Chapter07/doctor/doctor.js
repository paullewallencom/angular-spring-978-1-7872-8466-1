"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Doctor = (function () {
    function Doctor(firstname, lastname, email, specialityCode) {
        this.firstname = firstname;
        this.lastname = lastname;
        this.email = email;
        this.specialityCode = specialityCode;
    }
    return Doctor;
}());
exports.Doctor = Doctor;
//# sourceMappingURL=doctor.js.map