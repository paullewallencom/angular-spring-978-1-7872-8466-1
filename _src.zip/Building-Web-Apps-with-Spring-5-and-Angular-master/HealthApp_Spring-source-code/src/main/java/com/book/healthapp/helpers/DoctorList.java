package com.book.healthapp.helpers;

import java.util.ArrayList;

import com.book.healthapp.domain.Doctor;

public class DoctorList extends ArrayList<Doctor> {

}
